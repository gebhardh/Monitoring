# Test-PKI für log-puller mTLS

Schnelles Bootstrap einer privaten CA mit Server- und Client-Zertifikaten
für ein log-puller-Testsetup. Nicht für Produktion!

## Was du bekommst

```
.
├── ca/                          # Privates CA-Material
│   ├── ca.crt                   # CA-Zertifikat (verteilen an alle Hosts)
│   ├── ca.key                   # CA-Schlüssel (NIEMALS verteilen!)
│   └── serial                   # Counter für ausgestellte Certs
├── certs/                       # Alle Zertifikate und privaten Keys
│   ├── websrv1.internal.crt
│   ├── websrv1.internal.key
│   ├── ...
│   └── log-puller.{crt,key}     # Client-Cert für log-puller
└── bundles/                     # Versandfertige Tarballs pro Host
    ├── websrv1.internal.tar.gz
    ├── dbsrv1.internal.tar.gz
    ├── victorialogs.internal.tar.gz
    └── log-puller-host.tar.gz
```

Jedes Bundle enthält genau die Dateien, die der Zielhost braucht – plus ein
`install.sh`, das sie an die richtige Stelle kopiert.

## Schnellstart (5 Minuten)

```bash
# 1. Skripte ins Arbeitsverzeichnis
mkdir test-pki && cd test-pki
cp /path/to/scripts/*.sh ./
chmod +x *.sh

# 2. Hostnamen anpassen
$EDITOR 00-setup-example.sh
#   SERVER_HOSTS=("deinhost1:192.168.x.y" ...)
#   SINK_HOSTS=("vlogs:...")

# 3. Alles in einem Rutsch
./00-setup-example.sh
```

Fertig. In `bundles/` liegen jetzt die Tarballs für jeden Host.

## Verteilung

```bash
# Auf den jeweiligen Host kopieren
scp bundles/websrv1.internal.tar.gz websrv1.internal:/tmp/

# Auf dem Zielhost installieren
ssh websrv1.internal '
    cd /tmp
    tar xzf websrv1.internal.tar.gz -C /tmp/certs-install
    sudo /tmp/certs-install/install.sh
'
```

Oder per Ansible/Salt/Puppet – die Bundles sind einfache Tarballs.

## Detaillierter Workflow

### Schritt 1: CA erzeugen (einmalig)

```bash
./01-create-ca.sh
```

Erzeugt `ca/ca.key` (RSA-4096, 10 Jahre gültig) und das selbst-signierte
`ca/ca.crt`. Der private Key sollte das Verzeichnis nie verlassen.

**Wichtig**: `ca/ca.key` ist das Master-Geheimnis. Wer den hat, kann
beliebige Zertifikate ausstellen und sich als beliebiger Host ausgeben.
Backup auf einen verschlüsselten USB-Stick + Air-Gap-Speicherung ist
gute Praxis.

### Schritt 2: Server-Cert ausstellen

```bash
# Für einen Host mit Hostname und IP
./02-issue-cert.sh server websrv1.internal 192.168.1.10

# Nur mit Hostname (DNS-Auflösung muss klappen)
./02-issue-cert.sh server victorialogs.internal
```

Server-Certs bekommen:
- `extendedKeyUsage = serverAuth` (kein `clientAuth`)
- `subjectAltName = DNS:..., IP:...` für Hostname-Verifizierung
- 365 Tage Gültigkeit (anpassbar via `CERT_DAYS=...`)

### Schritt 3: Client-Cert ausstellen

```bash
./02-issue-cert.sh client log-puller
```

Client-Certs bekommen:
- `extendedKeyUsage = clientAuth`
- `subjectAltName = DNS:<name>` (für CN-Kompatibilität)

Im Test reicht **ein einziger Client-Cert** für log-puller, der dann gegen
alle Server- und Sink-Endpunkte verwendet wird.

### Schritt 4: Bundles erzeugen

```bash
./03-make-bundles.sh
```

Erzeugt pro Host einen Tarball mit:
- `ca.crt` – das CA-Zertifikat zur Verifikation
- `<name>.crt` – das eigene Zertifikat des Hosts
- `<name>.key` – der eigene Privat-Key (Mode 0600)
- `README.txt` – kurze Erklärung
- `install.sh` – kopiert Dateien an die richtige Stelle

## Hostnames und SANs - das Wichtigste

Der **Subject Alternative Name (SAN)** ist entscheidend. Moderne TLS-Clients
ignorieren das `CN`-Feld; nur SAN zählt. log-puller (bzw. Python's ssl)
prüft, ob der **Hostname, mit dem du verbindest**, im SAN steht.

**Konsequenz für dein Setup:**

| Du verbindest gegen | SAN muss enthalten |
|---|---|
| `https://websrv1.internal:19531` | `DNS:websrv1.internal` |
| `https://192.168.1.10:19531`     | `IP:192.168.1.10`     |

DNS-Auflösung muss auf dem log-puller-Host stimmen. Im Test geht auch
ein Eintrag in `/etc/hosts`:

```
192.168.1.10  websrv1.internal
192.168.1.20  dbsrv1.internal
```

## Konfiguration auf den Zielhosts

### journal-gatewayd auf einem Quell-Host

`systemd-journal-gatewayd` selbst hat begrenzte TLS-Unterstützung.
Praktisch verwendet man entweder:

**Variante A: Reverse-Proxy davorsetzen (empfohlen)**

```nginx
# /etc/nginx/sites-enabled/journal-gateway
server {
    listen 19532 ssl;
    server_name websrv1.internal;

    ssl_certificate     /etc/log-puller/certs/websrv1.internal.crt;
    ssl_certificate_key /etc/log-puller/certs/websrv1.internal.key;
    ssl_client_certificate /etc/log-puller/certs/ca.crt;
    ssl_verify_client on;

    location / {
        proxy_pass http://127.0.0.1:19531;
    }
}
```

Dann hört dein TLS-Endpoint auf Port 19532; journal-gatewayd selbst
bleibt nur auf 127.0.0.1 erreichbar.

**Variante B: systemd-journal-remote als Server (nativ TLS)**

`systemd-journal-remote` unterstützt TLS direkt, ist aber primär als
Empfänger gedacht (Push) und hat eine andere HTTP-API als gatewayd.

### log-puller-Konfiguration

```bash
# /etc/default/log-puller
SINK_URL="https://victorialogs.internal:9428/insert/jsonline"
SINK_TLS_CA="/etc/log-puller/certs/ca.crt"
SINK_TLS_CERT="/etc/log-puller/certs/log-puller.crt"
SINK_TLS_KEY="/etc/log-puller/certs/log-puller.key"

ENDPOINT_TLS_CA="/etc/log-puller/certs/ca.crt"
ENDPOINT_TLS_CERT="/etc/log-puller/certs/log-puller.crt"
ENDPOINT_TLS_KEY="/etc/log-puller/certs/log-puller.key"

ENDPOINT_WEBSRV1_URL="https://websrv1.internal:19532/entries"
ENDPOINT_DBSRV1_URL="https://dbsrv1.internal:19532/entries"
```

Im Test reicht eine einzige CA und ein einziger Client-Cert für alle
Endpunkte – deshalb hier nur die globalen `ENDPOINT_TLS_*`-Defaults.

## Verifikation und Debugging

### Cert ansehen

```bash
openssl x509 -in certs/websrv1.internal.crt -noout -text | less

# Kurzversion
openssl x509 -in certs/websrv1.internal.crt -noout \
    -subject -issuer -dates -ext subjectAltName,extendedKeyUsage
```

### Cert gegen CA verifizieren

```bash
openssl verify -CAfile ca/ca.crt certs/websrv1.internal.crt
# → certs/websrv1.internal.crt: OK
```

### TLS-Verbindung testen

```bash
# Server-Cert prüfen (ohne mTLS)
openssl s_client -connect websrv1.internal:19532 \
    -CAfile /etc/log-puller/certs/ca.crt -servername websrv1.internal

# Mit mTLS
openssl s_client -connect websrv1.internal:19532 \
    -CAfile /etc/log-puller/certs/ca.crt \
    -cert /etc/log-puller/certs/log-puller.crt \
    -key /etc/log-puller/certs/log-puller.key \
    -servername websrv1.internal

# Mit curl
curl --cacert /etc/log-puller/certs/ca.crt \
     --cert /etc/log-puller/certs/log-puller.crt \
     --key /etc/log-puller/certs/log-puller.key \
     https://websrv1.internal:19532/entries
```

### log-puller im Once-Modus testen

```bash
sudo -u log-puller /usr/bin/log-puller --once
# Zeigt Fehler direkt auf stderr
```

## Häufige Probleme

| Fehler | Ursache | Fix |
|---|---|---|
| `certificate verify failed: self-signed certificate` | CA-Bundle wird nicht genutzt | `SINK_TLS_CA`/`ENDPOINT_TLS_CA` setzen |
| `certificate verify failed: IP address mismatch` | Verbindung über IP, aber Cert hat nur DNS-SAN | Cert mit IP-SAN neu ausstellen oder Hostname verwenden |
| `certificate verify failed: Hostname mismatch` | Falscher Hostname im URL | DNS prüfen, `/etc/hosts` ergänzen |
| `certificate has expired` | Cert abgelaufen | Neu ausstellen (`02-issue-cert.sh`) |
| `bad certificate` (Server-side) | Client-Cert von falscher CA | Falsche CA auf Server-Seite konfiguriert |
| `unsupported protocol` | TLS-Version zu alt | Server auf min. TLSv1.2 konfigurieren |
| `permission denied` beim Lesen des Keys | Falsche Permissions | `0640 root:log-puller` |

## Cert-Rotation

Wenn ein Cert abläuft oder kompromittiert ist:

```bash
# Altes Cert löschen
rm certs/websrv1.internal.crt certs/websrv1.internal.key

# Neu ausstellen
./02-issue-cert.sh server websrv1.internal 192.168.1.10

# Bundle neu erzeugen und verteilen
./03-make-bundles.sh
scp bundles/websrv1.internal.tar.gz websrv1.internal:/tmp/

# Auf Zielhost:
sudo systemctl restart nginx           # bzw. journal-gatewayd
sudo systemctl restart log-puller      # auf log-puller-Host
```

log-puller liest Certs beim Start. Ein Restart genügt.

## Sicherheitshinweise (für späteren Produktivbetrieb)

Was an diesem Setup **nicht produktionsreif** ist:

- CA-Key liegt unverschlüsselt auf dem Build-Host (kein HSM, kein Passwort)
- Keine Certificate Revocation List (CRL) oder OCSP
- Keine Intermediate-CA (alles direkt von Root signiert)
- Cert-Laufzeit 365 Tage ist okay, aber kürzere Lifetimes mit Auto-Rotation
  sind in Prod besser (siehe [step-ca](https://smallstep.com/docs/step-ca/))
- Keine Trennung zwischen Cert-Authority und Operator

Für mehr als einen kleinen Test:

- **smallstep step-ca**: leichtgewichtige PKI mit ACME-Support
- **HashiCorp Vault PKI**: enterprise-grade, automatisches Renewal
- **cfssl**: CloudFlare-Tooling, gut skriptbar
- **EJBCA**: vollständige Enterprise-PKI

## Aufräumen

```bash
# Alles weg (CAREFUL!)
rm -rf ca/ certs/ bundles/
```

Auf den Zielhosts:

```bash
sudo rm -rf /etc/log-puller/certs/*
```
