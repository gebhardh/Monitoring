#!/bin/bash
# 00-setup-example.sh
# All-in-one Beispiel: erzeugt CA, alle Certs und alle Bundles in einem Rutsch.
#
# Nach Ausführung hast du:
#   ca/                  - CA-Material
#   certs/               - alle Zertifikate
#   bundles/             - versandfertige Tarballs pro Host
#
# Anpassen: HOSTS, CLIENTS und SINK_HOSTS für deine Umgebung.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# --- Hier deine Hosts eintragen ---

# journal-gatewayd Server-Hosts: "hostname:zusätzliche-IP-oder-Alias"
SERVER_HOSTS=(
    "websrv1.internal:192.168.1.10"
    "websrv2.internal:192.168.1.11"
    "dbsrv1.internal:192.168.1.20"
)

# Sink-Hosts (VictoriaLogs, Loki etc.)
SINK_HOSTS=(
    "victorialogs.internal:192.168.1.50"
)

# Clients (log-puller)
CLIENTS=(
    "log-puller"
)

# --- Workflow ---

echo ""
echo "============================================"
echo " Schritt 1: CA erzeugen"
echo "============================================"
if [[ ! -f ./ca/ca.crt ]]; then
    "$SCRIPT_DIR/01-create-ca.sh"
else
    echo "CA existiert bereits, übersprungen."
fi

echo ""
echo "============================================"
echo " Schritt 2: Server-Certs ausstellen"
echo "============================================"
for entry in "${SERVER_HOSTS[@]}" "${SINK_HOSTS[@]}"; do
    IFS=':' read -r host extra_san <<< "$entry"
    if [[ -f "./certs/$host.crt" ]]; then
        echo "  $host: existiert, übersprungen"
        continue
    fi
    if [[ -n "$extra_san" ]]; then
        "$SCRIPT_DIR/02-issue-cert.sh" server "$host" "$extra_san"
    else
        "$SCRIPT_DIR/02-issue-cert.sh" server "$host"
    fi
done

echo ""
echo "============================================"
echo " Schritt 3: Client-Certs ausstellen"
echo "============================================"
for client in "${CLIENTS[@]}"; do
    if [[ -f "./certs/$client.crt" ]]; then
        echo "  $client: existiert, übersprungen"
        continue
    fi
    "$SCRIPT_DIR/02-issue-cert.sh" client "$client"
done

echo ""
echo "============================================"
echo " Schritt 4: Bundles erzeugen"
echo "============================================"
"$SCRIPT_DIR/03-make-bundles.sh"

echo ""
echo "============================================"
echo " Fertig!"
echo "============================================"
echo ""
echo "Bundles zum Verteilen:"
ls -1 bundles/*.tar.gz 2>/dev/null || echo "  (keine)"
echo ""
echo "Nächste Schritte:"
echo "  1. Bundles auf die jeweiligen Hosts kopieren (scp)"
echo "  2. Auf jedem Host das install.sh aus dem Bundle ausführen"
echo "  3. journal-gatewayd auf Server-Hosts mit TLS konfigurieren"
echo "  4. log-puller-Konfiguration auf TLS umstellen"
