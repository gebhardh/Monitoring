#!/bin/bash
# 02-issue-cert.sh
# Stellt ein Server- oder Client-Zertifikat aus, signiert von der lokalen CA.
#
# Verwendung:
#   ./02-issue-cert.sh server <hostname> [<weitere-san> ...]
#   ./02-issue-cert.sh client <client-name>
#
# Beispiele:
#   ./02-issue-cert.sh server websrv1.internal 192.168.1.10
#   ./02-issue-cert.sh server victorialogs.internal
#   ./02-issue-cert.sh client log-puller
#
# Output:
#   certs/<name>.key  - privater Schlüssel
#   certs/<name>.crt  - öffentliches Zertifikat
#
# Bei Server-Certs werden Hostname und ggf. IP als SAN eingetragen,
# damit clients die Identität verifizieren können.

set -euo pipefail

CA_DIR="${CA_DIR:-./ca}"
CERTS_DIR="${CERTS_DIR:-./certs}"
CERT_DAYS="${CERT_DAYS:-365}"
KEY_BITS="${KEY_BITS:-2048}"

if [[ $# -lt 2 ]]; then
    echo "Usage: $0 server|client <name> [<additional-san> ...]" >&2
    echo "" >&2
    echo "Beispiele:" >&2
    echo "  $0 server websrv1.internal 192.168.1.10" >&2
    echo "  $0 client log-puller" >&2
    exit 1
fi

ROLE="$1"
NAME="$2"
shift 2
ADDITIONAL_SANS=("$@")

if [[ "$ROLE" != "server" && "$ROLE" != "client" ]]; then
    echo "Error: role must be 'server' or 'client', got '$ROLE'" >&2
    exit 1
fi

if [[ ! -f "$CA_DIR/ca.key" || ! -f "$CA_DIR/ca.crt" ]]; then
    echo "Error: CA in $CA_DIR not found. Run 01-create-ca.sh first." >&2
    exit 1
fi

mkdir -p "$CERTS_DIR"

KEY_FILE="$CERTS_DIR/$NAME.key"
CSR_FILE="$CERTS_DIR/$NAME.csr"
CRT_FILE="$CERTS_DIR/$NAME.crt"
EXT_FILE="$CERTS_DIR/$NAME.ext"

if [[ -f "$CRT_FILE" ]]; then
    echo "Error: $CRT_FILE existiert bereits. Erst manuell löschen, wenn du es neu ausstellen willst." >&2
    exit 1
fi

echo "=== Erzeuge $ROLE-Cert für: $NAME ==="

# Privater Schlüssel
openssl genrsa -out "$KEY_FILE" "$KEY_BITS"
chmod 0600 "$KEY_FILE"

# CSR (Certificate Signing Request)
openssl req -new -key "$KEY_FILE" -out "$CSR_FILE" \
    -subj "/CN=$NAME/O=log-puller test"

# Extensions definieren - Server vs Client unterscheiden sich
# in Key Usage und Extended Key Usage
if [[ "$ROLE" == "server" ]]; then
    # SAN für Server-Cert: hostname + zusätzliche
    SAN_LINES="DNS:$NAME"
    for san in "${ADDITIONAL_SANS[@]}"; do
        # IP vs DNS unterscheiden
        if [[ "$san" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            SAN_LINES="$SAN_LINES,IP:$san"
        else
            SAN_LINES="$SAN_LINES,DNS:$san"
        fi
    done

    cat > "$EXT_FILE" <<EOF
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = $SAN_LINES
EOF
    echo "  SANs: $SAN_LINES"
else
    # Client-Cert
    cat > "$EXT_FILE" <<EOF
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature
extendedKeyUsage = clientAuth
subjectAltName = DNS:$NAME
EOF
fi

# Signieren mit der CA
openssl x509 -req \
    -in "$CSR_FILE" \
    -CA "$CA_DIR/ca.crt" -CAkey "$CA_DIR/ca.key" \
    -CAserial "$CA_DIR/serial" \
    -out "$CRT_FILE" \
    -days "$CERT_DAYS" \
    -sha256 \
    -extfile "$EXT_FILE"

# Aufräumen: CSR und Ext-File brauchen wir nicht mehr
rm -f "$CSR_FILE" "$EXT_FILE"

echo ""
echo "=== $ROLE-Cert ausgestellt ==="
echo "  Cert:  $CRT_FILE"
echo "  Key:   $KEY_FILE"
echo ""
openssl x509 -in "$CRT_FILE" -noout -subject -issuer -dates -ext subjectAltName,extendedKeyUsage 2>/dev/null \
    || openssl x509 -in "$CRT_FILE" -noout -subject -issuer -dates
