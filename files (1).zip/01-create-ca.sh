#!/bin/bash
# 01-create-ca.sh
# Erzeugt eine selbst-signierte Root-CA für das Test-Setup.
#
# Output:
#   ca/ca.key   - privater CA-Schlüssel (STRENG GEHEIM, niemals weitergeben!)
#   ca/ca.crt   - öffentliches CA-Zertifikat (auf allen Hosts verteilen)
#
# Verwendung:
#   ./01-create-ca.sh

set -euo pipefail

CA_DIR="${CA_DIR:-./ca}"
CA_NAME="${CA_NAME:-log-puller-test-ca}"
CA_DAYS="${CA_DAYS:-3650}"        # 10 Jahre für die CA
CA_KEY_BITS="${CA_KEY_BITS:-4096}"

mkdir -p "$CA_DIR"
chmod 0700 "$CA_DIR"

if [[ -f "$CA_DIR/ca.key" ]]; then
    echo "Error: $CA_DIR/ca.key existiert bereits. Abbruch zum Schutz vor Überschreiben." >&2
    exit 1
fi

echo "=== Erzeuge Root-CA: $CA_NAME ==="

# Privater Schlüssel der CA
openssl genrsa -out "$CA_DIR/ca.key" "$CA_KEY_BITS"
chmod 0600 "$CA_DIR/ca.key"

# Selbst-signiertes CA-Zertifikat
openssl req -x509 -new -nodes \
    -key "$CA_DIR/ca.key" \
    -sha256 -days "$CA_DAYS" \
    -out "$CA_DIR/ca.crt" \
    -subj "/CN=$CA_NAME/O=log-puller test"

# Serial-Counter für ausgestellte Certs initialisieren
echo "01" > "$CA_DIR/serial"

echo ""
echo "=== CA erzeugt ==="
echo "  CA cert:  $CA_DIR/ca.crt"
echo "  CA key:   $CA_DIR/ca.key  (STRENG GEHEIM)"
echo ""
openssl x509 -in "$CA_DIR/ca.crt" -noout -subject -dates
echo ""
echo "Nächster Schritt: ./02-issue-cert.sh server <hostname>"
