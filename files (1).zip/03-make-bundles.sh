#!/bin/bash
# 03-make-bundles.sh
# Erzeugt versandfertige Cert-Bundles pro Host.
# Ein Bundle enthält genau das, was der jeweilige Host braucht - nichts mehr.
#
# Verwendung:
#   ./03-make-bundles.sh
#
# Output:
#   bundles/<hostname>.tar.gz   - eines pro Host, mit korrektem Inhalt

set -euo pipefail

CA_DIR="${CA_DIR:-./ca}"
CERTS_DIR="${CERTS_DIR:-./certs}"
BUNDLE_DIR="${BUNDLE_DIR:-./bundles}"

if [[ ! -f "$CA_DIR/ca.crt" ]]; then
    echo "Error: $CA_DIR/ca.crt not found. Run 01-create-ca.sh first." >&2
    exit 1
fi

mkdir -p "$BUNDLE_DIR"

make_bundle() {
    local target_name="$1"
    local role="$2"          # 'server' oder 'client'
    local cert_name="$3"     # Basename in certs/

    local crt="$CERTS_DIR/$cert_name.crt"
    local key="$CERTS_DIR/$cert_name.key"

    if [[ ! -f "$crt" || ! -f "$key" ]]; then
        echo "  SKIP $target_name (Cert für '$cert_name' fehlt)" >&2
        return
    fi

    local stage
    stage=$(mktemp -d)

    # Inhalt zusammenstellen
    cp "$CA_DIR/ca.crt" "$stage/ca.crt"
    cp "$crt"           "$stage/$cert_name.crt"
    cp "$key"           "$stage/$cert_name.key"
    chmod 0600 "$stage/$cert_name.key"

    # README im Bundle
    cat > "$stage/README.txt" <<EOF
Cert-Bundle für: $target_name ($role)

Enthalten:
  ca.crt              - Root-CA-Zertifikat (zur Verifikation des Gegenübers)
  $cert_name.crt      - Eigenes Zertifikat
  $cert_name.key      - Privater Schlüssel (NIEMALS weitergeben!)

Empfohlene Ablage auf dem Zielsystem (siehe install.sh im Bundle):
  /etc/log-puller/certs/ca.crt           (0644 root:root)
  /etc/log-puller/certs/$cert_name.crt   (0644 root:root)
  /etc/log-puller/certs/$cert_name.key   (0640 root:log-puller)
EOF

    # install.sh: Hilfsskript, das die Dateien an die richtige Stelle kopiert
    cat > "$stage/install.sh" <<'BUNDLE_INSTALL_EOF'
#!/bin/bash
# install.sh - kopiert die Bundle-Inhalte an die richtige Stelle.
# Auf dem Zielsystem ausführen (sudo). Funktioniert für log-puller-Hosts;
# für journal-gatewayd-Hosts ggf. Pfade anpassen.
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Muss als root ausgeführt werden." >&2
    exit 1
fi

TARGET_DIR="/etc/log-puller/certs"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

mkdir -p "$TARGET_DIR"
chmod 0750 "$TARGET_DIR"

# log-puller-Gruppe für Key-Lesbarkeit (existiert wenn das Paket installiert ist)
KEY_GROUP="root"
if getent group log-puller >/dev/null 2>&1; then
    KEY_GROUP="log-puller"
    chown root:log-puller "$TARGET_DIR"
fi

for f in "$SCRIPT_DIR"/*.crt; do
    install -m 0644 -o root -g root "$f" "$TARGET_DIR/"
done

for f in "$SCRIPT_DIR"/*.key; do
    install -m 0640 -o root -g "$KEY_GROUP" "$f" "$TARGET_DIR/"
done

echo "Certs installiert in $TARGET_DIR:"
ls -la "$TARGET_DIR"
BUNDLE_INSTALL_EOF
    chmod 0755 "$stage/install.sh"

    # Tarball erzeugen (absoluter Pfad, da wir in $stage cd'en)
    local out
    out="$(cd "$BUNDLE_DIR" && pwd)/$target_name.tar.gz"
    (cd "$stage" && tar -czf "$out" --owner=0 --group=0 .)
    rm -rf "$stage"

    echo "  $out"
}

echo "=== Erzeuge Cert-Bundles ==="

# Hier definierst du die Zuordnung Hostname -> Cert-Name
# Anpassen: Welche Bundles brauchst du?
# Format: target_name | role | cert_name (Basename in certs/)
declare -a TARGETS=(
    # Server-Hosts (laufen journal-gatewayd)
    "websrv1.internal|server|websrv1.internal"
    "websrv2.internal|server|websrv2.internal"
    "dbsrv1.internal|server|dbsrv1.internal"
    # Sink (z. B. VictoriaLogs)
    "victorialogs.internal|server|victorialogs.internal"
    # Client (log-puller)
    "log-puller-host|client|log-puller"
)

for entry in "${TARGETS[@]}"; do
    IFS='|' read -r target role cert <<< "$entry"
    make_bundle "$target" "$role" "$cert"
done

echo ""
echo "=== Bundles erzeugt in $BUNDLE_DIR/ ==="
ls -lh "$BUNDLE_DIR/"
echo ""
echo "Verteilen z.B. mit:"
echo "  scp $BUNDLE_DIR/<host>.tar.gz <host>:/tmp/"
echo "  ssh <host> 'cd /tmp && tar xzf <host>.tar.gz && sudo ./install.sh'"
