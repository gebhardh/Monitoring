# Nginx → Alloy → Logstash → OpenSearch: Setup-Dokumentation

## Übersicht

Diese Dokumentation beschreibt die Konfiguration einer Log-Pipeline, die Nginx-Access-Logs im JSON-Format über **Grafana Alloy** und **Logstash** nach **OpenSearch** überträgt.

```
Nginx (JSON-Log) → Grafana Alloy → Logstash → OpenSearch
```

---

## Komponenten

| Komponente | Aufgabe | Konfigurationsdatei |
|---|---|---|
| Nginx | Erzeugt strukturierte JSON-Logs | `nginx-json-logging.conf` |
| Grafana Alloy | Liest Log-Dateien, parst JSON, leitet weiter | `alloy-config.alloy` |
| Logstash | Verarbeitet, anreichert und indiziert Logs | `logstash-nginx-opensearch.conf` |
| OpenSearch | Speichert und indiziert die Log-Daten | — |

---

## 1. Nginx: JSON-Logging einrichten

### Log-Format

Die Datei `nginx-json-logging.conf` definiert das Log-Format `json_combined` mit folgenden Feldern:

| Feld | Bedeutung |
|---|---|
| `timestamp` | ISO8601-Zeitstempel des Requests |
| `remote_addr` | Client-IP-Adresse |
| `request_method` | HTTP-Methode (GET, POST, …) |
| `request_uri` | Angeforderter Pfad inkl. Query-String |
| `status` | HTTP-Statuscode |
| `body_bytes_sent` | Größe der Antwort in Bytes |
| `request_time` | Gesamtdauer des Requests in Sekunden |
| `upstream_response_time` | Antwortzeit des Upstream-Servers |
| `http_user_agent` | User-Agent-String des Clients |
| `ssl_protocol` / `ssl_cipher` | TLS-Informationen (bei HTTPS) |

### Installation

```bash
# Konfiguration einbinden
sudo cp nginx-json-logging.conf /etc/nginx/conf.d/

# In /etc/nginx/nginx.conf sicherstellen, dass gilt:
# include /etc/nginx/conf.d/*.conf;

# Konfiguration testen und neu laden
sudo nginx -t && sudo systemctl reload nginx
```

### Beispiel-Log-Eintrag

```json
{
  "timestamp": "2025-05-29T14:23:01+02:00",
  "remote_addr": "203.0.113.42",
  "request_method": "GET",
  "request_uri": "/api/products?limit=10",
  "status": 200,
  "body_bytes_sent": 1024,
  "request_time": 0.043,
  "http_user_agent": "Mozilla/5.0 ...",
  "host": "example.com"
}
```

---

## 2. Grafana Alloy: Log-Collection

### Aufgabe

Alloy übernimmt das Einlesen der Log-Dateien, parst die JSON-Struktur und leitet die Logs per **Loki-Push-API** an Logstash weiter.

### Pipeline im Überblick

```
local.file_match → loki.source.file → loki.process → loki.write
```

### Kernfunktionen der Alloy-Konfiguration

**Log Discovery** (`local.file_match`): Überwacht `/var/log/nginx/access.log` und erkennt Rotationen automatisch.

**JSON-Parsing** (`stage.json`): Extrahiert alle relevanten Felder aus dem JSON-Log-Eintrag.

**Label-Vergabe** (`stage.labels`): Setzt `status`, `request_method` und `host` als Loki-Labels für effiziente Filterung.

**Zeitstempel-Übernahme** (`stage.timestamp`): Nutzt den `timestamp`-Wert aus dem Log statt der Ingestion-Zeit.

**Fehler-Markierung**: 4xx- und 5xx-Requests werden automatisch mit `log_level=error` gelabelt.

### Installation und Start

```bash
# Alloy installieren (Debian/Ubuntu)
sudo apt-get install alloy

# Konfiguration kopieren
sudo cp alloy-config.alloy /etc/alloy/config.alloy

# Dienst starten
sudo systemctl enable --now alloy

# Status prüfen
sudo systemctl status alloy
```

### Umgebungsvariablen (optional)

```bash
# /etc/alloy/alloy.env
LOGSTASH_USER=alloy
LOGSTASH_PASSWORD=geheimes_passwort
```

---

## 3. Logstash: Verarbeitung und Transport

### Pipeline-Phasen

#### Input

Logstash empfängt die Logs von Alloy über HTTP auf Port `5044`. Drei Eingabe-Varianten sind als Kommentar hinterlegt:

- **HTTP-Input** (Standard): Alloy sendet per Loki-Push-API
- **Beats-Input**: Alternativ bei Beats-Protokoll-Konfiguration in Alloy
- **File-Input**: Direktes Lesen als Fallback ohne Alloy

#### Filter (Verarbeitungsschritte)

1. **Loki-Envelope auspacken**: Extrahiert die eigentliche Log-Nachricht aus der Loki-Datenstruktur
2. **Felder umbenennen**: Bringt alle Nginx-Felder auf die Root-Ebene des Dokuments
3. **Zeitstempel setzen**: Übernimmt den originalen Nginx-Zeitstempel als `@timestamp`
4. **Typkonvertierung**: Konvertiert `status`, `body_bytes_sent`, `request_time` in numerische Typen
5. **Status-Kategorie**: Leitet `status_category` (2xx_success, 4xx_client_error, etc.) ab
6. **URI aufteilen**: Trennt `uri_path` und `uri_query` aus der Request-URI
7. **User-Agent-Parsing**: Erkennt Browser, OS und Gerätetyp
8. **Feldbereinigung**: Ersetzt leere `-`-Werte durch leere Strings

#### Output

Logstash schreibt in OpenSearch mit tagesbasierten Indizes (`nginx-logs-YYYY.MM.dd`).

### Installation des OpenSearch-Output-Plugins

```bash
# In der Logstash-Installation
bin/logstash-plugin install logstash-output-opensearch

# Plugin-Version prüfen
bin/logstash-plugin list | grep opensearch
```

### Konfiguration kopieren und starten

```bash
sudo cp logstash-nginx-opensearch.conf /etc/logstash/conf.d/

# Umgebungsvariablen setzen (z. B. in /etc/logstash/logstash.env)
OPENSEARCH_USER=admin
OPENSEARCH_PASSWORD=sicheres_passwort

# Konfiguration testen
sudo /usr/share/logstash/bin/logstash --config.test_and_exit \
  -f /etc/logstash/conf.d/logstash-nginx-opensearch.conf

# Dienst starten
sudo systemctl enable --now logstash
```

---

## 4. OpenSearch: Index-Konfiguration

### Index-Muster

Logstash erstellt täglich neue Indizes nach dem Schema `nginx-logs-YYYY.MM.dd`, z. B.:

```
nginx-logs-2025.05.29
nginx-logs-2025.05.30
```

### Index-Template (empfohlen)

Legen Sie ein Template in OpenSearch an, das korrekte Feldtypen vorgibt:

```json
PUT _index_template/nginx-logs
{
  "index_patterns": ["nginx-logs-*"],
  "template": {
    "mappings": {
      "properties": {
        "@timestamp":             { "type": "date" },
        "http_status":            { "type": "integer" },
        "body_bytes_sent":        { "type": "long" },
        "request_time":           { "type": "float" },
        "upstream_response_time": { "type": "float" },
        "remote_addr":            { "type": "ip" },
        "uri_path":               { "type": "keyword" },
        "request_method":         { "type": "keyword" },
        "status_category":        { "type": "keyword" },
        "server_host":            { "type": "keyword" },
        "http_user_agent":        { "type": "text" },
        "user_agent.name":        { "type": "keyword" },
        "user_agent.os_name":     { "type": "keyword" }
      }
    },
    "settings": {
      "number_of_shards": 1,
      "number_of_replicas": 1
    }
  }
}
```

---

## 5. Netzwerk-Ports und Abhängigkeiten

```
Nginx          → Datei:  /var/log/nginx/access.log
Alloy          → Liest:  /var/log/nginx/access.log
Alloy          → Sendet: http://logstash:5044 (Loki-Push)
Logstash       → Sendet: https://opensearch:9200
OpenSearch     → Hört:   :9200 (HTTPS), :9600 (Metrics)
```

### Docker Compose (Minimalbeispiel)

```yaml
services:
  alloy:
    image: grafana/alloy:latest
    volumes:
      - ./alloy-config.alloy:/etc/alloy/config.alloy
      - /var/log/nginx:/var/log/nginx:ro
    command: run /etc/alloy/config.alloy

  logstash:
    image: opensearchproject/logstash-oss-with-opensearch-output-plugin:latest
    ports:
      - "5044:5044"
    volumes:
      - ./logstash-nginx-opensearch.conf:/usr/share/logstash/pipeline/nginx.conf
    environment:
      OPENSEARCH_USER: admin
      OPENSEARCH_PASSWORD: admin

  opensearch:
    image: opensearchproject/opensearch:latest
    environment:
      - discovery.type=single-node
      - OPENSEARCH_INITIAL_ADMIN_PASSWORD=Admin_1234!
    ports:
      - "9200:9200"
```

---

## 6. Troubleshooting

| Problem | Ursache | Lösung |
|---|---|---|
| Alloy liest keine neuen Zeilen | Berechtigungen auf Log-Datei | `chmod 644 /var/log/nginx/access.log` |
| Logstash: JSON-Parse-Fehler | Nginx-Log nicht reines JSON | `escape=json` in `log_format` prüfen |
| OpenSearch: Verbindungsfehler | TLS/Zertifikat-Problem | `ssl_certificate_verification => false` temporär setzen |
| Falsche Zeitstempel in OpenSearch | Zeitzone-Mismatch | `date`-Filter in Logstash anpassen |
| Fehlende Felder nach Parse | Loki-Envelope-Struktur geändert | Input-Typ in Logstash (Variante A/B/C) wählen |

### Alloy-Logs prüfen

```bash
journalctl -u alloy -f
```

### Logstash-Logs prüfen

```bash
tail -f /var/log/logstash/logstash-plain.log
```

### OpenSearch-Index prüfen

```bash
curl -k -u admin:admin https://localhost:9200/nginx-logs-*/_count
```

---

## 7. Sicherheitshinweise

- Nginx-Logs können personenbezogene Daten (IP-Adressen) enthalten → DSGVO beachten
- OpenSearch-Zugangsdaten **immer** über Umgebungsvariablen, nie im Klartext in Konfigurationsdateien
- TLS in Produktionsumgebungen obligatorisch (`ssl_certificate_verification => true`)
- Logstash-Port `5044` nur im internen Netz erreichbar machen (Firewall-Regel)
- Log-Rotation für Nginx konfigurieren (`logrotate`), damit Alloy die rotierten Dateien korrekt erkennt
